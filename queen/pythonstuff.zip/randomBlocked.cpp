#include <iostream>
#include <fstream>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <random>

using namespace std;


int randomzoro(int numberofbords){
    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<> dis(0,numberofbords);
    int randomX=dis(gen);
    return randomX;
}


int main(int argc, char **argv){
    if(argc!=3){
        cout<<"usage: "<<"./blocked <number_of_blocked> <range>\n";
        return 1;
    }
    ofstream f;
    f.open("blocked.lp", ofstream::out | ofstream::trunc);
    if(f.is_open()){
    int number=atoi(argv[1]);
    for(int i=0;i<number;++i){
        int bourds=atoi(argv[2]);
        f<<"blocked("<<randomzoro(bourds)<<","<<randomzoro(bourds)<<").\n";
    }
    f.close();
    }
    




    return 0;
}
