import os
import re
import time
mystring="gringo blocked.lp queensfaster.lp --const n=z | clasp 1"


start=input("Please enter a size of chess bourd: ")

file3=open("data3.txt","w")
for number in range(start,start+1):
    
    for numberblocked in range(0,100):
        cout=0
        for i in range(0,100):
            mystring=re.sub("z", str(number), mystring)
            start_time = time.time()
            cmd="./blocked "+str(numberblocked)+" "+str(number)
            os.system(cmd)
            x=os.popen(mystring).read() # This will run the command and return any output)
            print len(x)
            if str(len(x))<="195":
                cout=cout+1
            t=-(start_time-time.time())/2
            mystring=re.sub(str(start),"z", mystring)
        file3.write(str(numberblocked))
        file3.write("\t")
        file3.write(str(100-cout))
        file3.write("\n")
    file3.close()
os.system("gnuplot data3.gnu")

